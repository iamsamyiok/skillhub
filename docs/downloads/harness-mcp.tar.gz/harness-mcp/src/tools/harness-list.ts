import * as z from "zod/v4";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import type { Registry } from "../registry/index.js";
import type { HarnessClient } from "../client/harness-client.js";
import { jsonResult, errorResult, normalizeHarnessListPayload } from "../utils/response-formatter.js";
import { isUserError, isUserFixableApiError, toMcpError, enrichErrorWithHint, HarnessApiError } from "../utils/errors.js";
import { compactItems } from "../utils/compact.js";
import { applyUrlDefaults } from "../utils/url-parser.js";
import { asString, isRecord, coerceRecord } from "../utils/type-guards.js";
import type { SearchManager } from "../search/index.js";
import { buildResourceIndexContent } from "../search/embedding-content.js";
import { buildEntityDocumentId, buildEntityMetadata, resolveEntityScope } from "../search/entity-index.js";
import { orgIdField, projectIdField, resourceScopeSchema, resourceTypeSchema } from "./input-schemas.js";
import { listOutputSchema } from "./output-schemas.js";

export function registerListTool(server: McpServer, registry: Registry, client: HarnessClient, searchManager?: SearchManager): void {
  const filtersDesc =
    "Resource-specific filters as key-value pairs. Valid keys depend on resource_type — " +
    "call harness_describe(resource_type=\"<type>\") for filters, enums, and required fields for that type.";

  const listableTypes = registry.getTypesForOperation("list");

  server.registerTool(
    "harness_list",
    {
      description: "List Harness resources with filtering and pagination. Accepts a Harness URL to auto-extract scope. For project-scoped types, pass org_id and project_id on the first call unless the field descriptions name a configured default.",
      inputSchema: {
        resource_type: resourceTypeSchema(listableTypes).optional().describe("Resource type to list. Auto-detected from url."),
        url: z.string().optional().describe("Harness UI URL — auto-extracts org, project, and type"),
        resource_scope: resourceScopeSchema,
        org_id: orgIdField(registry.orgId),
        project_id: projectIdField(registry.projectId),
        page: z.number().default(0).optional().describe("Page number, 0-indexed"),
        size: z.number().min(1).max(100).default(20).optional().describe("Page size (1–100). Some resource types enforce a lower max (e.g. security_exemption max 50) — call harness_describe for per-resource limits."),
        search_term: z.string().optional().describe("Filter results by name or keyword"),
        compact: z.boolean().default(true).optional().describe("Strip verbose metadata from list items, keeping only essential fields (default true)"),
        params: z.record(z.string(), z.unknown()).optional().describe("Additional identifiers for nested resources (e.g. repo_id for pull requests). Call harness_describe for fields per resource_type."),
        filters: z.record(z.string(), z.unknown()).optional().describe(filtersDesc),
      },
      outputSchema: listOutputSchema,
      annotations: {
        title: "List Harness Resources",
        readOnlyHint: true,
        destructiveHint: false,
        openWorldHint: true,
      },
    },
    async (args) => {
      try {
        const { params, filters, ...rest } = args;
        // Use coerceRecord to handle LLMs that serialize objects as JSON strings
        const coercedParams = coerceRecord(params);
        const coercedFilters = coerceRecord(filters);
        // Merge params/filters in before URL defaults so explicit identifiers (e.g. FME's
        // workspace_id, passed via filters) are visible to applyUrlDefaults's
        // legacy-vs-URL-scope precedence check, not just top-level named args.
        const argsForUrlDefaults = { ...rest, ...coercedParams, ...coercedFilters };
        const input = applyUrlDefaults(argsForUrlDefaults as Record<string, unknown>, args.url, { includeResourceScope: true });
        // Spread caller-supplied params (path identifiers) and filters into the input
        if (coercedParams) Object.assign(input, coercedParams);
        if (coercedFilters) Object.assign(input, coercedFilters);
        const resourceType = asString(input.resource_type);
        if (!resourceType) {
          return errorResult("resource_type is required. Provide it explicitly or via a Harness URL.");
        }
        if (resourceType === "template" && input.template_list_type === undefined) {
          input.template_list_type = "All";
        }
        // Map URL-derived resource_id onto required parent list filters (e.g. RMG release_id).
        if (!input.release_id && input.resource_id) {
          try {
            const def = registry.getResource(resourceType);
            if (def.listFilterFields?.some((f) => f.name === "release_id" && f.required)) {
              input.release_id = input.resource_id;
            }
          } catch {
            /* resource_type validated below */
          }
        }
        const rawResult = await registry.dispatch(client, resourceType, "list", input);
        const page = typeof args.page === "number" ? args.page : 0;
        const result = normalizeHarnessListPayload(rawResult, { page });

        // Apply compact mode — strip verbose metadata from list items.
        // Skip when the endpoint spec has opted out via `skipCompact` (marker
        // propagated as non-enumerable `__skipCompact` by the registry).
        const resultSkipCompact = isRecord(result) && (result as Record<string, unknown> & { __skipCompact?: boolean }).__skipCompact === true;
        if (args.compact !== false && !resultSkipCompact && isRecord(result)) {
          const items = result.items;
          if (Array.isArray(items)) {
            const compactFn = registry.getResource(resourceType).compactItem;
            result.items = compactItems(items, compactFn);
          }
        }

        // Fire-and-forget: index items for semantic search (skipped in multi-user + local)
        if (searchManager && isRecord(result) && Array.isArray(result.items)) {
          const accountId = client.account;
          void Promise.all(
            (result.items as Array<Record<string, unknown>>).map(item => {
              const identifier = asString(item["identifier"]) ?? asString(item["id"]);
              if (!identifier) return Promise.resolve();
              const entityScope = resolveEntityScope(registry, resourceType, input);
              return searchManager.indexItem({
                id: buildEntityDocumentId(accountId, resourceType, identifier, entityScope),
                content: buildResourceIndexContent(resourceType, item),
                corpus: "entities",
                accountId,
                metadata: buildEntityMetadata(resourceType, identifier, String(item["name"] ?? ""), entityScope),
              });
            })
          ).catch(() => { /* never surface indexing errors to caller */ });
        }

        return jsonResult(result);
      } catch (err) {
        if (isUserError(err)) return errorResult(err.message);
        if (isUserFixableApiError(err)) {
          const rt = asString(args.resource_type);
          let hint: string | undefined;
          if (err instanceof HarnessApiError && err.statusCode === 404 && rt) {
            try { hint = registry.getResource(rt).diagnosticHint; } catch { /* unknown type */ }
          }
          return errorResult(enrichErrorWithHint(err.message, hint));
        }
        throw toMcpError(err);
      }
    },
  );
}
