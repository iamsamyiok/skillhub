# Lessons Learned

## Nested File Paths Must Keep Slashes
- **Issue**: Registry `pathParams` run `encodeURIComponent` on the whole file path, so `src/index.ts` became `src%2Findex.ts` and the content API 404'd. Empty `path` was also treated as unset, so `harness_get` mapped `resource_id` onto it. List deep links need `{filePath}` on items; a custom `compactItem` that drops `openInHarness` strips those links in `harness_list`.
- **Fix**: `pathBuilder` encodes each path segment and allows `/content` with no extra path. Treat `input[field] === undefined` (not falsy) when mapping `resource_id`. Stamp `filePath` in the list extractor and keep `openInHarness` in `compactItem`.
- **Rule**: For multi-segment file paths, never encode slashes. Empty string is an explicit identifier. Custom compact functions must preserve `openInHarness`.
- **Follow-up**: Branch names, tags, and diff ranges with slashes have the same encoding rule as nested file paths. `branch` get/delete, `tag` delete, and `commit` diff/diff_stats must encode each path segment, not `encodeURIComponent` on the whole ref. Code files URLs stay typed as `file_content` but also stamp `branch_name` so an explicit `resource_type=branch` can get/delete that ref. Do not copy the file-path `resource_id` onto a non-`file_content` type — `harness_delete` treats `resource_id` and `branch_name` as the same identifier and would conflict. Stamp `branch_name` from `/files/{ref}` only, not from a `gitRef` query (that value can be a commit SHA).

## CCM Open Recommendations Use daysBack, Not the Date Picker
- **Issue**: Chat showed OPEN recs (e.g. `prod-nodepool-v2`) that the CCM Recommendations page hides. The UI date picker is `appliedAt*` and is ignored unless state is APPLIED-only. OPEN freshness is `daysBack: 4` on `lastProcessedAt`. Mapping the calendar to `days_back=30` re-includes stale recs.
- **Fix**: REST list/stats/count default to the Open-tab payload (`daysBack: 4`, `minSaving: 1`, `OPEN`). Applied-only omits `daysBack` and sends `applied_at_start`/`applied_at_end`. Keep `cost_category` + `cost_buckets` for per-team filters.
- **Rule**: Never treat the recommendations calendar as OPEN lookback. `days_back` is last-processed TTL; `appliedAt*` is Applied-tab only.

## GitHub Action Tags Must Match the Published Ref Exactly
- **Issue**: The Trivy release page labels the latest release `v0.36.0`, but the workflow initially referenced `0.36.0`; GitHub Actions failed during job setup because that ref does not exist.
- **Fix**: Use the exact published action ref, including its `v` prefix, and verify the repository tag before pushing.
- **Rule**: Treat marketplace display versions and Git refs as different inputs; resolve the exact action tag or commit SHA before adding a third-party action.

## HTTP Transport Tests Need Localhost Socket Access
- **Issue**: Running the full suite in the restricted sandbox made HTTP transport tests fail with `listen EPERM: operation not permitted 127.0.0.1`, while all non-socket tests passed.
- **Fix**: Rerun the same suite with localhost socket access before treating route, auth, host-validation, or rate-limit failures as product regressions.
- **Rule**: A cluster of HTTP test failures sharing `listen EPERM` is an environment failure; report both runs and require a clean socket-enabled rerun for the functional verdict.

## Generated Docs Checks Must Run After Build Completes
- **Issue**: Running `pnpm build` and `pnpm docs:check` concurrently lets the docs checker read a partially rewritten `build/`, producing false resource-count and operation-table drift even when README is current.
- **Fix**: Complete `pnpm build` first, then run `pnpm docs:check` or `pnpm docs:generate` sequentially. A sequential regenerate after the false failure reported README already up to date.
- **Rule**: Never parallelize build with commands that consume `build/`; fresh-build ordering is a correctness requirement, not only a CI convention.

## Full Vitest Runs Should Not Compete With Overlapping Suites
- **Issue**: Running `pnpm test` concurrently with `pnpm standards:check` caused the timing-sensitive semantic-search manager test to exceed its 5-second timeout even though the same full suite passed immediately when run alone.
- **Fix**: Run the full Vitest suite by itself; use parallelism for independent non-Vitest checks instead of launching overlapping test pools.
- **Rule**: Treat a timeout under concurrent local test load as resource contention until an isolated rerun reproduces it, and report both results.

## Production Shrinkwraps Need a Production Staging Manifest
- **Issue**: `npm-shrinkwrap.json` intentionally captures the production dependency tree and npm-native mirrors of the repository's pnpm security overrides. Running `npm ci --omit=dev` against that shrinkwrap and the full development `package.json` still makes npm validate missing dev dependencies and ignore `pnpm.overrides`, so MCPB staging fails even though the release shrinkwrap check is healthy.
- **Fix**: Generate a minimal staging `package.json` with runtime dependencies, optional dependencies, and transitive pnpm overrides mirrored into npm's `overrides`, then run `npm ci` against the checked-in shrinkwrap.
- **Rule**: When consuming a production-only shrinkwrap outside npm publish, pair it with the same production manifest shape used to generate it; `--omit=dev` changes installation, not lockfile validation.

## List-Filter Enums Must Be Canonicalized at Dispatch
- **Issue**: `listFilterFields.enum` is only visible via `harness_describe`. The global `harness_list` schema cannot encode per-resource enums, so agents often send lowercase (`pending`) while APIs require PascalCase/UPPERCASE. Those 400s count as `tool_error` and can page on-call.
- **Fix**: `canonicalizeListFilterEnums` in `Registry.dispatch` rewrites case-insensitive matches to declared enum values (including comma-separated tokens). Also clarify that some resources have a lower `size` max than the global 1–100 tool schema.
- **Correction**: The first implementation also threw on values with no enum match. That broke two existing suites — `cost_timeseries` deliberately falls back to `LAST_30_DAYS` for unrecognized `time_filter`, and a connector test passed an undeclared `category`. `listFilterFields.enum` is hand-maintained documentation across 200+ resource types, so it can lag the API; using it as a hard gate would reject values the backend accepts.
- **Rule**: Treat `listFilterFields.enum` as a normalization hint, not a validation contract. Canonicalize casing, pass unmatched values through to the API, and never let doc metadata become a gate. Do not silently clamp pagination; keep fail-loud with a clear max hint.

## Historical Test Helpers Must Be Revalidated Against Current Runtime Architecture
- **Issue**: Issue #119 and its original `fullRegistryV0` / `fullRegistryV1` helpers were created when `HARNESS_PIPELINE_VERSION` filtered one pipeline type out of the Registry. A later change made `pipeline` and `pipeline_v1` simultaneously available and reduced the config to a default preference, but the first implementation treated the stale helpers as two real variants, duplicated every invariant over identical objects, inferred opt-in resources from default/full set differences, and used a hand-built array instead of an end-to-end Registry fixture.
- **Fix**: Trace current constructor behavior and relevant history before preserving an old helper. Use one full Registry for the current architecture, derive opt-in coverage from `ToolsetDefinition.optIn`, and inject malformed regression definitions through `RegistryOptions.additionalToolsets` so fixtures traverse the same Registry and validator path as production definitions.
- **Rule**: When an issue references historical configuration variants, verify that the config still changes runtime structure on current main. Regression tests must enter through the same construction and iteration path they claim to protect, and environment-specific full-suite failures should be compared against a clean-main baseline before being attributed to the diff.

## Scope Defaults and Remote Branch Context Must Stay End-to-End
- **Issue**: Multi-scope path builders can bypass the registry's usual config defaulting when they construct path segments themselves. For IDP entities, list used configured `HARNESS_ORG` / `HARNESS_PROJECT`, while get/update path construction fell back to account scope, so a list -> update flow could target a different entity with the same kind/id.
- **Fix**: Path builders that encode scope in the path must accept `PathBuilderConfig`, honor explicit `resource_scope`, use configured org/project defaults when scope is omitted and the resource's list/default behavior does so, and clear unused scope fields so query params match the path.
- **Rule**: For multi-scope resources with custom path builders, test omitted-scope defaulting and explicit account/org/project overrides through the public tool handler when writes are supported.
- **Issue**: Remote pipeline execution has multiple helper calls before the final run. Passing branch context to the input-set GET but not to the runtime-template fetch can silently resolve inline overrides against a different Git branch.
- **Fix**: Use one normalized branch source (`pipeline_branch ?? branch`) for every pre-execute pipeline helper call and the final execute request.
- **Rule**: When adding or fixing remote pipeline branch handling, assert every request in the chain (input set GET, runtime input template, execute POST) carries the same branch/repo/connector/store context.

## Read Cache Signals Must Not Block Execute Paths
- **Issue**: A remote pipeline `pipeline.get` response can report `cacheResponse.cacheState=STALE_CACHE` and old YAML from the read/UI cache, while pipeline execution is documented to fetch entities from Git for the selected pipeline branch.
- **Fix**: Do not fail-close `harness_execute` based on `pipeline.get` cache metadata. Preserve explicit branch selection by sending `pipelineBranchName` for remote executions, and only block execution on signals from the execute path itself.
- **Rule**: A preflight may only block an operation when it proves the same backend path the operation will use. If a check observes a read-model/cache path, surface it as diagnostic context at most, not as execution authority.

## Multipart Tool Contracts
- **Issue**: Multipart body builders can hide unsafe defaults or malformed encoded inputs until after request construction, and execute shorthands can drift from generic `resource_id` mapping.
- **Fix**: Validate encoded content before `Buffer.from`, enforce documented scalar/enum types inside multipart builders, reject disallowed or mutually exclusive payload variants when present, require parent IDs explicitly when the API needs location context, accept the registry's mapped primary identifier in execute body builders, reject conflicting resource-specific aliases in shorthand and full-body modes, and document operation-specific body contracts via `paramsSchema`/`bodySchema`.
- **Rule**: For multipart resources, fail loudly before network I/O and add regressions for generic tool paths (`resource_id` -> resource identifier), alias conflicts in every accepted input shape, direct helper inputs, and `harness_describe` body/params metadata. If create and update have different one-of requirements, split the body schemas instead of relying on one ambiguous shared schema.

## Execute Action Scope and Read-Only Semantics
- **Issue**: A read-like endpoint modeled as an execute action can drift from the generic read/list/get contract: `resource_scope` may be unavailable on the public execute tool, URL-derived scope may not be merged, and read-only mode may block the action solely because it is under `harness_execute`.
- **Fix**: Expose `resource_scope` on execute when execute actions use multi-scope resources, opt the handler into URL-derived resource scope, and gate read-only mode by the action's `operationPolicy.risk` instead of the tool family alone.
- **Rule**: For any execute action with `risk: "read"` or multi-scope support, add regressions for the registered tool input schema, explicit and URL-derived `resource_scope`, and read-only mode behavior.

## Endpoint-Specific Node Type Constraints
- **Issue**: Reusing a general FileStoreNode enum for a folder-only endpoint let agents construct `FILE` requests that the backend endpoint should reject.
- **Fix**: Add endpoint-specific validators and schema descriptions when an API accepts only one value from a broader shared model.
- **Rule**: If an endpoint path names a subtype such as `/folder`, do not surface the full shared enum unless that exact endpoint accepts every enum value. Add helper and `harness_describe` metadata regressions for rejected enum values.

## URL-Derived Scope Must Match Tool Surfaces
- **Issue**: URL parsing can synthesize `resource_scope`, but a tool that exposes `resource_scope` still ignores URL-derived scope unless it opts into `applyUrlDefaults(..., { includeResourceScope: true })`.
- **Fix**: Keep URL-derived scope behavior aligned across every public tool that accepts `resource_scope`, including create/update/delete paths, and test scoped URLs at the tool-handler level.
- **Rule**: When adding a resource type to the URL-derived scope allowlist, audit every tool that accepts both `url` and `resource_scope`; either opt the tool in or avoid advertising URL-derived scope for that resource.

## URL-Derived IDs Must Match Tool Schemas
- **Issue**: A tool can advertise URL-derived IDs while its schema still requires an explicit `resource_id`, so strict MCP clients reject URL-only calls before handler defaulting can run.
- **Fix**: If URL copy says an ID is extracted, make the public schema accept URL-only input and map the resolved URL/defaulted `resource_id` into the resource-specific identifier field before dispatch.
- **Rule**: For any write tool that advertises URL ID extraction, add handler-level regressions that omit `resource_id` and prove the URL-derived ID reaches the backend path.

## Harness SAT Account Extraction
- **Issue**: Service account tokens can use the same account-scoped segment shape as PATs, but the parser only recognized the `pat` prefix.
- **Fix**: Extract account IDs from both `pat` and `sat` prefixes, and let multi-user HTTP sessions derive `HARNESS_ACCOUNT_ID` from either prefix when `x-harness-account-id` is omitted.
- **Rule**: Before requiring explicit account IDs for new Harness API key types, check whether the token format embeds the account ID segment; preserve explicit account overrides and mismatch validation.

## MCP SDK v1.27+ Type Compatibility
- **Issue**: `server.tool()` callback return type requires `[key: string]: unknown` index signature on the result object.
- **Fix**: Add `[key: string]: unknown` to the ToolResult interface.
- **Rule**: Always check MCP SDK type expectations for return types before defining custom interfaces.

## MCP SDK Prompt API
- **Issue**: `server.prompt()` does NOT accept an array of `{ name, description, required }` for args. It uses a Zod schema object.
- **Fix**: Use `{ paramName: z.string().describe("...").optional() }` format for prompt argument schemas.
- **Rule**: Check the actual SDK `.d.ts` types, not just documentation examples that may be outdated.

## Harness Artifact Registry (HAR) BuildAndPush Step
- **Issue**: HAR uses a different spec shape than third-party Docker registries in `BuildAndPushDockerRegistry` steps. Initially assumed HAR just swaps `connectorRef` to `account.harnessImage` — wrong.
- **Correct HAR spec**: Uses `registryRef` (NOT `connectorRef`). There is NO `connectorRef` at all. `repo` and `registryRef` are both typically `<+input>`.
- **Correct third-party spec**: Uses `connectorRef` (NOT `registryRef`). There is NO `registryRef`.
- **Rule**: HAR and third-party Docker registries are the same step type (`BuildAndPushDockerRegistry`) but mutually exclusive field sets: `registryRef` for HAR, `connectorRef` for third-party. Never mix them.

## LLM Prompt Reliability: Use Exact YAML Templates, Not Prose
- **Issue**: Prose instructions like "use registryRef instead of connectorRef" are unreliable — LLMs still mix up fields ~50% of the time.
- **Fix**: Embed exact copy-paste YAML templates (labeled TEMPLATE A / TEMPLATE B) directly in prompts. LLMs reliably copy from concrete examples.
- **Rule**: When a prompt needs the LLM to generate YAML with variant configurations, always provide the complete YAML snippet for each variant. Prose descriptions of field differences are insufficient.

## Chaos API Base Path
- **Issue**: Chaos toolset previously returned HTTP 404 for all requests (experiments, probes, infrastructures) across projects.
- **History**: The `/gateway` prefix was originally required but has since been removed. The correct base path is now `/chaos/manager/api`.
- **Fix**: Use `/chaos/manager/api` as the chaos API base path.
- **Rule**: When adding new Harness module toolsets, verify the API base path. Modules such as SEI and log-service use `/gateway/` prefix; chaos, ng, pipeline, code, cf, etc. do not.

## Pagination Parity Testing (v1 vs v2)
- **Methodology**: Use the same scope for both v1 and v2 (either both account-level OR both project-level). Compare the first element of page 2 from v1 with the first element of page 2 from v2.
- **Pass criteria**: If the first element of page 2 matches across both servers → pagination parity ✓
- **Fail criteria**: If they differ (same scope) → investigate (API params, sort order, date filters, etc.)
- **Rule**: Apply this pattern to all tools when testing pagination across MCP v1 and v2.

## Product Credentials in Multi-User Mode
- **Issue**: A deployment-level product credential can silently override the per-session credential after `mergeConfigWithSessionHeaders()` injects the user's API key, breaking shared HTTP auth isolation.
- **Fix**: Reject server-held product credentials in `HARNESS_MCP_MODE=multi-user` unless there is an explicit per-session credential channel, and defensively ignore shared product credentials in auth resolvers for multi-user configs.
- **Rule**: For any product-specific auth config, test the full multi-user path: base config → session header merge → product auth resolver. The resolved product credential must remain tied to the session user or fail closed.

## Public Config Surface Alignment
- **Issue**: Adding or documenting an env var without updating packaged manifests leaves manifest-driven and MCPB installs unable to configure it.
- **Fix**: Update `manifest.json`, `mcp-directory/manifest.json`, and release metadata tests for every public config knob exposed in source docs or `.env.example`.
- **Rule**: Before finishing env config changes, search all public config surfaces and lock the expected manifest exposure in tests.

## GUI MCP Client Executable Paths
- **Issue**: GUI MCP clients may not inherit shell `PATH`, so examples using bare executable names can still fail with `spawn <command> ENOENT`.
- **Fix**: For Cursor and similar GUI-client examples, show absolute executable paths and include the Node directory in `env.PATH`.
- **Rule**: When documenting GUI-client stdio MCP configs, avoid PATH-dependent `command` values unless the surrounding text explicitly scopes them to shell-based clients.

## Runtime Payload Documentation
- **Issue**: Documentation can overstate a payload contract by describing intended fields that the current tool handlers do not populate.
- **Fix**: Either wire the field through the runtime path in the same PR or document the current emitted shape precisely.
- **Rule**: Before documenting audit, schema, or tool payload fields as guaranteed, verify the exact dispatch path and at least one focused runtime/test assertion.

## Logger-Filtered Audit Sinks
- **Issue**: Saying stderr audit output is always emitted hides that the stderr sink routes through the shared logger and respects `LOG_LEVEL`.
- **Fix**: Document stderr as registered by default, and direct durable audit collection to file or webhook sinks.
- **Rule**: For telemetry sinks built on shared logging, document both registration and filtering semantics.

## Public Tool-Contract Discipline (Knowledge Graph / semantic-layer PR)
- **Context**: The KG/semantic-layer OSS port (PR #255) took four "Sunil On Demand Architecture Review" (Cursor bot) rounds. Every finding fell into a small set of repeatable public-contract categories — capturing them here so future resources clear review in one pass.
- **Patterns and fixes**:
  - **Raw passthrough leaks the backend envelope.** `hql_query.run` shipped `responseExtractor: passthrough`, forwarding query-service debug/meta fields across the tool boundary. Fix: project a stable shape (`hqlRunExtract` → `{columns, rows, stats}`, unwrapping a `data`/`result` envelope). Never `passthrough` on a real endpoint.
  - **Published field name must match its source.** `kg_queryable_type_summary` filled `connectorId` from `connector_reference.connector_name` (a display label), making the documented JOIN key unstable. Fix: prefer `connector_identifier`/`identifier`, fall back to name only if that is all the API returns.
  - **`stripInternalMeta()` correctness in both directions.** Pruning on the pre-recursion shape both dropped meaningful empty collections (`{relationship_types: []}` → `{}`) and left `{}` placeholder rows (`{fields:[{columnMappingMeta:{...}}]}` → `{fields:[{}]}`). Fix: recurse first, preserve explicitly-empty arrays, then prune array elements that collapse to `{}`. Also re-strip any raw `obj.*` fields reattached after the initial strip (e.g. `dcs_enrichment` join_predicates/references/fields), since they re-introduce nested `columnMappingMeta`.
  - **Body builders must not silent-drop falsy values.** `hqlRunBody` used truthiness (`timeoutMs ? ...`), rewriting `timeout_ms: 0` out of the request. Fix: `!= null` checks so `0`/`false` reach the API or fail loudly.
  - **Read-only/confirmation gating is risk-based, not tool-family-based.** The batch-HQL path blocked all execute actions in read-only mode while `registry.dispatchExecute()` allows `risk: "read"`. Fix: gate on `actionSpec.operationPolicy.risk !== "read"`, mirroring the registry. Classify `risk` by behavior — HQL is a pure query language (find/filter/select/join, no mutations), so `run` is `risk: "read"`, not `low_write`.
  - **List-only metadata on get-only resources misleads discovery.** `kg_related_type` (get-only) set `listFilterFields`, so `harness_describe`/`harness_list` advertised `kind`/`include_transitive` as list filters. Fix: drop `listFilterFields`; document get params via the get op's `paramsSchema`. Add local required-field validation (throw a plain `Error` from the body builder → surfaces as a clean `errorResult` via `isUserError`) so a missing id fails locally instead of sending an id-less body.
- **Rule**: For every new/changed resource, run the **Pre-Push Architecture-Review Pass** in `AGENTS.md` §Workflow 7 before pushing, and pair every new extractor/body builder with both a response-shape test (envelope dropped, empty/edge cases) and a request-shape test. "No focused coverage" is itself a recurring review finding.
- **Build/docs gotcha**: `pnpm docs:generate` and `docs:check` read from `build/`. Always `pnpm build` first or counts go stale and CI `docs:check` fails.

## External PR Hygiene (Sunil review, PR #325)
- **Issue**: Commit message `fix: [AIDEVOSP-1830]: …` exposed an internal Jira ID in the public `mcp-server` repo.
- **Fix**: Use user-facing commit/PR text (e.g. `fix: skip resource discovery when org/project defaults are missing`) with no ticket prefix.
- **Rule**: Never put Harness-internal ticket IDs in external PR titles, descriptions, or commit messages — see **Pre-Push Architecture-Review Pass** in `AGENTS.md` §Workflow 7.

## v1 Pipeline Examples: Converter Output Is Ground Truth, Not the Bundled Schema
- **Context**: Aligning `src/data/examples/pipeline-v1.ts` to real v1 conversions from the harness pipeline converter (the comparison HTML reports).
- **Finding**: The bundled `src/data/schemas/v1/pipeline.ts` is stricter than what the live v1 converter emits. ALL real converter outputs (verified 60/60 via ajv) fail that schema on the same points the hand-written examples did: `runtime: shell: true` and `runtime: kubernetes:` object forms (schema's RuntimeV1 oneOf rejects them as written), `runtime.kubernetes.node: {}` (K8RuntimeSpec is `additionalProperties:false`, no `node`), and `environment: {name}` (env object rejects `name`). The examples are NOT validated against the schema by any test (`harness-schema-examples.test.ts` only checks registry lookup), so schema-failures there are not CI failures.
- **Canonical real v1 idioms** (from 2061 conversions): pipeline children are exactly `clone,id,name,stages,inputs,notifications,template,delegate,barriers` — `id` NOT `identifier`, no `version:` under `pipeline:`. Steps use a key (`run:`/`template:`/`group:`/`parallel:`/`approval:`) — never `type: run`/`spec`. `run: {script, shell, container, output, env}`. `template: {uses, with}`. Runtime is `shell: true` or a `kubernetes:` block (`automount-service-token, connector, namespace, node: {}, os: Linux`) — `vm:`/`cloud:` essentially unused. `type: agent`/`mcp_servers`/`tools`/`model`/`prompt` appear ZERO times (those live only in the separate `agent-pipeline` schema, not `pipeline_v1`).
- **Rule**: When the task is "match the examples to real converted YAML," the converter reports are the source of truth, not the in-repo JSON schema. Confirm no test validates the example YAML against the schema before treating schema-conformance as a hard constraint. To check format claims at scale, parse the report HTML's `<pre>` v1 columns and substring/ajv-test against the corpus rather than eyeballing a couple.

## IaCM Writes: Scope Symmetry, Cross-Repo Contract, User Flow (#810 review)
- **Issue**: Module create/update remapped `org_id`/`project_id` → `scope_org`/`scope_project` only on writes, while list/get stayed account-default. Agents could create org/project modules they could not then list or get. README still said "account-scoped." Tests locked in the remap instead of the flow.
- **Root cause**: Optimized for "make POST/PUT match OpenAPI writes" and skipped (1) list/get against the same backend contract, (2) sibling multi-scope pattern from `iacm_variable_set`, (3) end-to-end agent flow create → list → get → update at the same scope.
- **Fix**: Declare scope on the resource (`supportedScopes` + `scopeParams` + `scopeOptional`), remove per-op remaps, document visibility scope vs body connector `org`/`project`, add ambient-config + list/get symmetry regressions.
- **Rule**: Before shipping IaCM (or any multi-scope) writes:
  1. Check **all** CRUD ops on the owning service OpenAPI for scope params — not just create/update.
  2. Prefer resource-level scope (`supportedScopes` / `scopeParams` / `scopeOptional`) over silent per-op `queryParams` remaps.
  3. Match the nearest sibling in the same toolset (variable sets for IaCM multi-scope) before inventing a new shape.
  4. Walk the **user flow**: create at org/project → list/get/update must work with the same `resource_scope` / org / project.
  5. Test ambient `HARNESS_ORG`/`HARNESS_PROJECT` does not leak when account is the default (`scopeOptional`).
  6. Update README when writes change the advertised scope model.
