# Personality & Voice Guide

Removing AI patterns is necessary but not sufficient. Text that's clean of AI tells can still read as sterile, voiceless, and institutional. This guide covers the positive dimension: what makes writing feel like a person wrote it.

> **Two guardrails before you use any of this.**
> 1. **Don't invent a person.** The first-person voice, opinions, and anecdotes below belong to writing that *has* an author (a personal post, a founder's note, an opinion piece). For impersonal copy — technical docs, reference text, third-party announcements — do **not** fabricate an "I"/"we" or a lived experience. An invented anecdote is a louder tell than the slop you removed.
> 2. **Don't mistake de-hedging for voice.** "Show uncertainty honestly" means drop *habitual* hedging, not load-bearing scope or certainty. In technical, legal, medical, or safety writing, "may", "preliminary", "does not establish causation", and "most (73%)" are the content — keep them.

---

## Signs of Soulless Writing

Text that passes all taboo-phrase checks but still feels off:

| Signal | What It Looks Like |
|--------|--------------------|
| No stance | States facts without interpretation or opinion |
| Uniform rhythm | Every sentence 12-16 words, same structure |
| Zero first person | Never says "I" or "we" — hides behind passive |
| No specificity | "Many companies" instead of naming one |
| Overly balanced | Presents all sides equally, never commits |
| No surprise | Every paragraph follows the expected arc |
| Sanitized vocabulary | Only uses "safe" words — nothing vivid or unusual |
| Perfect grammar | No fragments, contractions, or colloquialisms |

---

## How to Add Voice

### 1. Have Opinions

Voiceless: "There are advantages and disadvantages to remote work."
Human: "Remote work is better for deep work. Open offices are where focus goes to die."

State what you believe. Qualify only when accuracy demands it, not out of habit.

### 2. Vary Rhythm Deliberately

Voiceless: "The team reviewed the metrics. The team discussed the findings. The team decided on next steps."
Human: "The team reviewed metrics. Three hours of argument later, they had a plan. Not a great one, but a plan."

Mix short punches with longer flowing sentences. Break patterns. A fragment works. So does a 30-word sentence if it earns the length.

### 3. Be Specific

Voiceless: "The company experienced significant growth in the past year."
Human: "Revenue hit $4.2M, up from $1.8M twelve months ago."

Names, numbers, dates. Replace every "significant" with the actual data.

### 4. Use First Person When Natural

Voiceless: "It is recommended to ship early and iterate."
Human: "I ship early. Half the time the first version is wrong, but I learn faster than if I'd planned for six months."

"I" and "we" are not unprofessional. They signal a real person is speaking.

### 5. Leave Some Mess

Voiceless: "The approach combines agile methodology with user-centered design principles to deliver optimal outcomes."
Human: "We mashed agile and UCD together. It's messy but it works. Users get what they need faster."

Real writing has parenthetical asides, self-corrections, and imperfect phrasing. Overpolished prose reads as synthetic.

### 6. Show Uncertainty Honestly

Voiceless: "Further research is needed to determine the optimal approach."
Human: "I don't know the right answer yet. Two options look promising, and we'll know more after the pilot."

Admitting you don't know something is more human than hedging behind passive constructions. But this is for opinion and personal writing. In regulated or scientific content, "further research is needed" may be the precise, required claim — don't trade real epistemic caution for casual guesswork.

### 7. Use Concrete Sensory Language

Voiceless: "The office environment was suboptimal for productivity."
Human: "Fluorescent lights, a printer that jammed every third page, and a thermostat war that never ended."

Let the reader see, hear, feel the situation instead of categorizing it abstractly.

---

## Before/After: Full Passage

### Before (Clean but Soulless)
> Remote work has both benefits and challenges. Many organizations have adopted hybrid models. Research suggests that employee satisfaction increases with flexibility. Companies should consider their specific needs when designing work policies. The key is finding the right balance.

### After (Has Voice)
> I've worked remote for three years. Some weeks I get more done by Thursday than I used to in a full office week. Other weeks I don't put on pants until noon and accomplish nothing. The trick isn't policy, it's trust. Let people figure out where they work best and hold them to outcomes, not hours.

### What Changed
- Added first person and lived experience
- Replaced "many organizations" with a specific perspective
- Dropped the balanced-to-a-fault framing
- "Finding the right balance" (corporate nothing) became a concrete recommendation
- Included honest admission of unproductive days (human texture)

---

## Scoring Integration

When evaluating Human Authenticity (Rubric criterion 5), voice counts:

| Score | Voice Indicators |
|-------|-----------------|
| 5 | Clear authorial voice. Opinions stated. Rhythm varies. Could identify the writer. |
| 4 | Personality visible. Mostly specific. Minor generic patches. |
| 3 | Functional but anonymous. Could be anyone. No glaring AI tells. |
| 2 | Corporate-neutral. All hedged. No specificity. Reads as template. |
| 1 | Actively soulless. Reads like a policy document generated by committee. |

A score of 3 means the text is clean but not human. Aim for 4+.
