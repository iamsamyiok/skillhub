---
name: image-analysis
description: 识图理解（图片分析）：描述图片内容、提取图中文字（OCR）、分析页面/设计稿布局、比较图片。当用户给出图片并要求分析、理解、识别、提取文字、描述、总结、审查布局时使用。支持公网图片 URL 与本地图片（先上传）。
version: 1.0.0
---

# Skill: image-analysis（识图理解）

创建异步图片理解任务并轮询结果，拿到结构化的识图文本。禁止自行读取图片文件"假装分析"。

## 何时使用

- 提取图中文字（截图 OCR、票据、表格）
- 描述图片内容、总结截图信息
- 分析产品截图/设计稿的页面布局
- 图片转 Markdown / OCR 类任务（配合 docparse：PDF/Word/Excel 走 docparse_parse，单张图片走本技能）

## 标准工作流

1. **判断图片来源，拿到可访问 URL**：
   - 已是公网 `http(s)://` 真实域名图片 URL → 直接进第 2 步
   - 本地文件、工作区文件、聊天附件 → 先调 `image_analysis_upload_url(file_name)` 申请 upload_url（10 分钟有效）→ HTTP PUT 上传原始文件 → 用返回的 url
   - **禁止**传给服务：`file://`、localhost、裸 IP、内网地址、需要登录/VPN 的地址、相对路径
2. **创建任务**：`image_analysis_create_task(url, prompt?)`
   - prompt 可选，定制分析口径，例如：
     - "提取图中所有文字，保持原有结构"
     - "描述这张图片的主要内容与风格"
     - "分析页面布局：模块划分、信息层级、视觉动线"
3. **轮询结果**：`image_analysis_get_result(task_id)`，按复杂度决定节奏：
   - 简单 OCR/短描述：5-20 秒
   - 普通产品截图/页面布局：20-60 秒
   - 复杂设计稿/大图/结构化分析：60-120 秒
4. **取结果**：
   - `status=succeeded` → `text` 字段即识图结果，整理后答复用户
   - `status=failed` → 向用户转述 `error_message`
   - 未完成 → 继续轮询，不要自行编造结果

## 注意

- 结果未就绪时**绝不**根据截图印象或想象编造分析内容，以轮询返回的 text 为准
- 多图任务逐张创建、逐个轮询，串行执行
- 上传类 upload_url 有 10 分钟时效，过期重新申请
