# MCP Common

Shared stateless MCP SDK v2 infrastructure for the Cloudflare MCP Workers.

## Package boundary

`mcp-common` owns behavior that every server needs: stateless transport assembly, OAuth and API-token routing, request-scoped auth/account context, metrics, Sentry integration, and Cloudflare API error handling.

Product-specific tool registrars, schemas, and API adapters live in their owning app. Modules reused by multiple apps are explicit under `src/shared-tools` and `src/shared-prompts`:

- documentation search is shared by Docs AI Search, Workers Bindings, and Workers Observability
- Workers tools are shared by Workers Bindings, Workers Builds, and Workers Observability
- zone tools are shared by DNS Analytics and GraphQL

The separate `@repo/tools` package contains monorepo command-line scripts for linting, typechecking, releases, and deployment. It does not contain MCP tools.

## Application assembly

Use `createPublicMcpApp()` or `createAuthenticatedMcpApp()` for application entrypoints. These modules centralize the invariants shared by every deployment:

- server name and version from `MCP_SERVER_NAME` and `MCP_SERVER_VERSION`
- request and tool metrics through `MCP_METRICS`
- localhost Host/Origin policy
- the Cloudflare MCP playground Origin policy
- a fresh SDK v2 server for every request
- the default stateless 2025 compatibility path
- the `/sse` URL alias for the same Streamable HTTP handler as `/mcp`
- OAuth and API-token routing for authenticated applications

```ts
import { createAuthenticatedMcpApp } from '@repo/mcp-common/src/mcp-app'

const app = createAuthenticatedMcpApp<Env>({
	serviceHostnames: ['example-staging.mcp.cloudflare.com', 'example.mcp.cloudflare.com'],
	scopes: ExampleScopes,
	register(context) {
		context.registerTool('whoami', { inputSchema: z.object({}) }, async () => ({
			content: [{ type: 'text', text: context.props?.type ?? 'anonymous' }],
		}))
	},
})

export const mcpHandler = app.mcpHandler
export default app.worker
```

`mcpHandler` is exposed separately for transport-contract tests that bypass OAuth routing. Applications with a genuine custom route, such as an asset fallback, can call it directly from their own Worker `fetch` implementation.

For lower-level use, `createCloudflareMcpHandler()` accepts explicit server metadata, observability factories, and HTTP policy. It delegates protocol routing, CORS, Host/Origin validation, and legacy compatibility to `createMcpHandler()` from the isolated `agents/mcp/server` entry point. Do not construct a global MCP server. Do not set `legacy: 'reject'`: the default `legacy: 'stateless'` fallback is part of the migration contract.

The shared handler serves `POST` and CORS `OPTIONS` on `/mcp` and `/sse`. The latter is a URL alias, not the deprecated HTTP+SSE transport. A legacy SSE `GET /sse` request returns `410 Gone` with an `application/problem+json` body that offers two Streamable HTTP migrations: keep the existing URL by changing the configured transport, or switch to the recommended `/mcp` URL for future compatibility. The SDK continues to return `405` for other stateless legacy stream and session-deletion requests. MCP request bodies are capped at 4 MiB before SDK parsing, and OAuth resources use strict path-aware matching.

## Request registration context

The registration callback receives one request-local `McpRegistrationContext` containing:

- Worker `env`
- validated auth `props`
- the original `Request`
- `ExecutionContext` and a bound `waitUntil`
- SDK request context (`era` and optional caller-supplied `AuthInfo`)
- tracked `registerTool()` and `accountTool()` methods
- `registerPrompt()` and `recordError()` methods

The raw SDK server stays private. This prevents application registration code from bypassing shared tool metrics, error reporting, or account selection accidentally.

Shared tools capture the registration context instead of a stateful server object. Account-scoped tools use `context.accountTool()` with a `z.object(...)` input schema. Account selection is resolved anew on every request: auth-pinned account, then `cf-account-id`, then the `account_id` argument.

## Authentication routing

`createAuthenticatedMcpApp()` composes `createCloudflareOAuthRouter()` internally. OAuth grants, KV, credentials, refresh tokens, and API-token validation remain application/security state; only MCP protocol sessions are removed. `/mcp` and `/sse` use the same handler while retaining exact path-aware OAuth resource matching.

Workers OAuth Provider and API-token routing populate `ExecutionContext.props`. The request-scoped server factory reads and validates `ctx.props` before setting `McpRegistrationContext.props`. SDK `ctx.http.authInfo` is optional and is present only when a compatible caller supplies it. Do not log raw tokens or authentication props.

The default CORS allow-headers list includes `cf-account-id`, `MCP-Protocol-Version`, `Mcp-Method`, and `Mcp-Name`. Browser deployments use the canonical explicit Host and Origin allowlists assembled from each application's `serviceHostnames`.
