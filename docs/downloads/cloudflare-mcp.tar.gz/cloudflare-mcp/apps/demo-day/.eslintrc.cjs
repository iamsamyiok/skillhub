/** @type {import("eslint").Linter.Config} */
module.exports = {
	root: true,
	extends: ['@repo/eslint-config/default.cjs'],
	ignorePatterns: ['frontend/**', 'worker-configuration.d.ts'],
}
