import { z } from 'zod'

import { getCloudflareClient } from '@repo/mcp-common/src/cloudflare-api'
import { requireRequestProps } from '@repo/mcp-common/src/request-context'

import type { McpRegistrationContext } from '@repo/mcp-common/src/registration-context'

/** Selects the browser that renders the page. Browser Run uses Chrome when this is not set. */
const browserParam = z
	.enum(['kitesurf'])
	.optional()
	.describe(
		'Browser that renders the page. Omit to use the default Chrome browser. Set to "kitesurf" to use the Kitesurf browser engine.'
	)

/** Query string that routes a quick action to the requested browser. Empty for the default. */
function browserSearch(browser: z.infer<typeof browserParam>): string {
	return browser ? `?${new URLSearchParams({ browser })}` : ''
}

export function registerBrowserTools<Env>(context: McpRegistrationContext<Env>) {
	context.accountTool(
		'get_url_html_content',
		{
			description: 'Get page HTML content',
			inputSchema: z.object({
				url: z.string().url(),
				browser: browserParam,
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const r = await client.browserRendering.content.create(
					{
						account_id: accountId,
						url: params.url,
					},
					{ query: params.browser ? { browser: params.browser } : undefined }
				)

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({
								result: r,
							}),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error getting page html: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'get_url_markdown',
		{
			description: 'Get page converted into Markdown',
			inputSchema: z.object({
				url: z.string().url(),
				browser: browserParam,
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const query = browserSearch(params.browser)
				const r = (await client.post(`/accounts/${accountId}/browser-run/markdown${query}`, {
					body: {
						url: params.url,
					},
				})) as { result: string }

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({
								result: r.result,
							}),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error getting page in markdown: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'get_url_screenshot',
		{
			description: 'Get page screenshot',
			inputSchema: z.object({
				url: z.string().url(),
				viewport: z
					.object({
						height: z.number().default(600),
						width: z.number().default(800),
					})
					.optional(),
				browser: browserParam,
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const query = browserSearch(params.browser)
				const r = await client
					.post(`/accounts/${accountId}/browser-run/screenshot${query}`, {
						body: {
							url: params.url,
							viewport: params.viewport,
						},
						__binaryResponse: true,
					})
					.asResponse()

				const arrayBuffer = await r.arrayBuffer()
				const base64Image = Buffer.from(arrayBuffer).toString('base64')

				return {
					content: [
						{
							type: 'image',
							mimeType: 'image/png',
							data: base64Image,
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error getting page screenshot: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'get_url_pdf',
		{
			description: 'Render a page to PDF',
			inputSchema: z.object({
				url: z.string().url(),
				browser: browserParam,
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const query = browserSearch(params.browser)
				const r = await client
					.post(`/accounts/${accountId}/browser-run/pdf${query}`, {
						body: {
							url: params.url,
						},
						__binaryResponse: true,
					})
					.asResponse()

				const arrayBuffer = await r.arrayBuffer()
				const base64Pdf = Buffer.from(arrayBuffer).toString('base64')

				return {
					content: [
						{
							type: 'resource',
							resource: {
								uri: params.url,
								mimeType: 'application/pdf',
								blob: base64Pdf,
							},
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error getting page pdf: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'get_url_snapshot',
		{
			description: 'Get page HTML content and a screenshot in a single call',
			inputSchema: z.object({
				url: z.string().url(),
				browser: browserParam,
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const query = browserSearch(params.browser)
				const r = (await client.post(`/accounts/${accountId}/browser-run/snapshot${query}`, {
					body: {
						url: params.url,
					},
				})) as { result: { content?: string; screenshot?: string } }

				const content: Array<
					{ type: 'text'; text: string } | { type: 'image'; mimeType: string; data: string }
				> = [
					{
						type: 'text',
						text: JSON.stringify({ content: r.result?.content }),
					},
				]

				if (r.result?.screenshot) {
					content.push({
						type: 'image',
						mimeType: 'image/png',
						data: r.result.screenshot,
					})
				}

				return { content }
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error getting page snapshot: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'scrape_url_elements',
		{
			description: 'Scrape elements from a page by CSS selector',
			inputSchema: z.object({
				url: z.string().url(),
				elements: z
					.array(
						z.object({
							selector: z.string(),
						})
					)
					.min(1)
					.describe('CSS selectors of the elements to scrape'),
				browser: browserParam,
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const query = browserSearch(params.browser)
				const r = (await client.post(`/accounts/${accountId}/browser-run/scrape${query}`, {
					body: {
						url: params.url,
						elements: params.elements,
					},
				})) as { result: unknown }

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({ result: r.result }),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error scraping page: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'get_url_json',
		{
			description:
				'Extract structured JSON from a page using AI. Provide a prompt and/or a response_format JSON schema to guide extraction.',
			inputSchema: z.object({
				url: z.string().url(),
				prompt: z.string().optional().describe('Natural-language instruction for what to extract'),
				response_format: z
					.object({
						type: z.string(),
						json_schema: z.unknown().optional(),
					})
					.optional()
					.describe('Optional JSON-schema response format to constrain the output'),
				browser: browserParam,
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const query = browserSearch(params.browser)
				const r = (await client.post(`/accounts/${accountId}/browser-run/json${query}`, {
					body: {
						url: params.url,
						...(params.prompt ? { prompt: params.prompt } : {}),
						...(params.response_format ? { response_format: params.response_format } : {}),
					},
				})) as { result: unknown }

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({ result: r.result }),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error getting page json: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'get_url_links',
		{
			description: 'Get the list of links on a page',
			inputSchema: z.object({
				url: z.string().url(),
				visibleLinksOnly: z
					.boolean()
					.optional()
					.describe('Only return links that are visible in the rendered page'),
				browser: browserParam,
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const query = browserSearch(params.browser)
				const r = (await client.post(`/accounts/${accountId}/browser-run/links${query}`, {
					body: {
						url: params.url,
						...(params.visibleLinksOnly !== undefined
							? { visibleLinksOnly: params.visibleLinksOnly }
							: {}),
					},
				})) as { result: unknown }

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({ result: r.result }),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error getting page links: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'start_crawl',
		{
			description:
				'Start an asynchronous crawl of a website. Returns a job_id — poll get_crawl_result to retrieve records.',
			inputSchema: z.object({
				url: z.string().url(),
				render: z
					.boolean()
					.default(true)
					.describe('Whether to render pages with a browser (vs. fetching raw HTML)'),
				depth: z.number().int().min(1).optional().describe('How many links deep to crawl'),
				limit: z.number().int().min(1).optional().describe('Maximum number of pages to crawl'),
				browser: browserParam.describe(
					'Browser that renders the crawled pages. Omit to use the default Chrome browser. Set to "kitesurf" to use the Kitesurf browser engine. Requires render to be true.'
				),
			}),
		},
		async (params, accountId) => {
			if (params.browser && !params.render) {
				return {
					content: [
						{
							type: 'text',
							text: 'Error starting crawl: browser can only be set when render is true',
						},
					],
					isError: true,
				}
			}

			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const r = (await client.post(`/accounts/${accountId}/browser-run/crawl`, {
					body: {
						url: params.url,
						render: params.render,
						...(params.depth !== undefined ? { depth: params.depth } : {}),
						...(params.limit !== undefined ? { limit: params.limit } : {}),
						// Unlike quick actions, the crawl endpoint reads `browser` from the body.
						...(params.browser ? { browser: params.browser } : {}),
					},
				})) as { result: string }

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({
								job_id: r.result,
								message: 'Crawl started. Poll get_crawl_result with this job_id.',
							}),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error starting crawl: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'get_crawl_result',
		{
			description: 'Get the status and records of a crawl job started with start_crawl',
			inputSchema: z.object({
				job_id: z.string(),
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const r = (await client.get(
					`/accounts/${accountId}/browser-run/crawl/${params.job_id}`
				)) as { result: unknown }

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({ result: r.result }),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error getting crawl result: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'cancel_crawl',
		{
			description: 'Cancel a running crawl job',
			inputSchema: z.object({
				job_id: z.string(),
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				const r = (await client.delete(
					`/accounts/${accountId}/browser-run/crawl/${params.job_id}`
				)) as { result: unknown }

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({ result: r.result ?? 'cancelled' }),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error cancelling crawl: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'list_browser_sessions',
		{
			description: 'List active Browser Run sessions for the account',
			inputSchema: z.object({}),
		},
		async (_params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				// This endpoint returns a bare JSON array of sessions, not the
				// usual `{ success, result }` envelope, so use the response as-is.
				const r = (await client.get(
					`/accounts/${accountId}/browser-run/devtools/session`
				)) as unknown
				const result =
					r && typeof r === 'object' && 'result' in r ? (r as { result: unknown }).result : r

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({ result }),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error listing browser sessions: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)

	context.accountTool(
		'kill_browser_session',
		{
			description: 'Close (kill) a Browser Run session by its session ID',
			inputSchema: z.object({
				session_id: z.string(),
			}),
		},
		async (params, accountId) => {
			try {
				const props = requireRequestProps(context)
				const client = getCloudflareClient(props.accessToken)
				await client.delete(
					`/accounts/${accountId}/browser-run/devtools/browser/${params.session_id}`
				)

				return {
					content: [
						{
							type: 'text',
							text: JSON.stringify({
								session_id: params.session_id,
								status: 'killed',
							}),
						},
					],
				}
			} catch (error) {
				return {
					content: [
						{
							type: 'text',
							text: `Error killing browser session: ${error instanceof Error && error.message}`,
						},
					],
					isError: true,
				}
			}
		}
	)
}
