export interface Env {
	OAUTH_KV: KVNamespace
	MCP_COOKIE_ENCRYPTION_KEY: string
	ENVIRONMENT: 'development' | 'staging' | 'production' | 'test'
	MCP_SERVER_NAME: string
	MCP_SERVER_VERSION: string
	CLOUDFLARE_CLIENT_ID: string
	CLOUDFLARE_CLIENT_SECRET: string
	MCP_METRICS: AnalyticsEngineDataset
	CLOUDFLARE_API_TOKEN: string
	OPENAI_API_KEY: string
	AI_GATEWAY_TOKEN: string
	CLOUDFLARE_ACCOUNT_ID: string
	AI_GATEWAY_ID: string
	DOCS_AI_SEARCH: AiSearchInstance
	VECTORIZE: VectorizeIndex
	DEV_DISABLE_OAUTH: string
	DEV_CLOUDFLARE_API_TOKEN: string
	DEV_CLOUDFLARE_EMAIL: string
}
