module github.com/github/github-mcp-server

go 1.25.12

require (
	github.com/go-chi/chi/v5 v5.3.2
	github.com/go-viper/mapstructure/v2 v2.5.0
	github.com/google/go-github/v89 v89.0.1-0.20260728185857-34349a88bac3
	github.com/google/jsonschema-go v0.4.3
	github.com/josephburnett/jd/v2 v2.5.0
	github.com/lithammer/fuzzysearch v1.1.8
	github.com/microcosm-cc/bluemonday v1.0.27
	github.com/modelcontextprotocol/go-sdk v1.7.0
	github.com/muesli/cache2go v0.0.0-20221011235721-518229cd8021
	github.com/shurcooL/githubv4 v0.0.0-20240727222349-48295856cce7
	github.com/shurcooL/graphql v0.0.0-20230722043721-ed46e5a46466
	github.com/spf13/cobra v1.10.2
	github.com/spf13/pflag v1.0.10
	github.com/spf13/viper v1.21.0
	github.com/stretchr/testify v1.12.1
	github.com/yosida95/uritemplate/v3 v3.0.2
	golang.org/x/net v0.55.0
	golang.org/x/oauth2 v0.36.0
)

require (
	github.com/aymerick/douceur v0.2.0 // indirect
	github.com/fsnotify/fsnotify v1.9.0 // indirect
	github.com/google/go-querystring v1.2.0 // indirect
	github.com/gorilla/css v1.0.1 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/pelletier/go-toml/v2 v2.2.4 // indirect
	github.com/sagikazarmark/locafero v0.11.0 // indirect
	github.com/segmentio/asm v1.1.3 // indirect
	github.com/segmentio/encoding v0.5.4 // indirect
	github.com/sourcegraph/conc v0.3.1-0.20240121214520-5f936abd7ae8 // indirect
	github.com/spf13/afero v1.15.0 // indirect
	github.com/spf13/cast v1.10.0 // indirect
	github.com/stretchr/objx v0.5.3 // indirect
	github.com/subosito/gotenv v1.6.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/sys v0.45.0 // indirect
	golang.org/x/text v0.37.0 // indirect
	golang.org/x/time v0.15.0 // indirect
)
