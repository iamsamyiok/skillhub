# Non-Latin languages (Chinese / Japanese / Korean / …)

The pipeline is Unicode-clean — python-pptx, the LibreOffice renderer, and PowerPoint
all handle non-Latin text. The deck won't break. The things that make it look *good*
(not just render) are **font glyph coverage**, **PowerPoint portability**, and a few
**script-specific typography** habits.

## Table of contents
- One language, consistently (the default)
- The one required change: set a script-appropriate font
- CJK typography habits (so it reads like a native deck, not translated)
- Write like a human — kill the "AI taste" in the copy (voice; most acute in 中文)
- Equations & figures
- Right-to-left scripts (Arabic / Hebrew) — limited
- Verify

## One language, consistently (the default)

**A deck is written in ONE language throughout** — every title, bullet, callout, label,
axis, footer, and the closing slide. This applies to every purpose, not just research. The most
common failure when building from source material in another language — an English-speaking PM
making a status deck from a Chinese vendor's docs, a product team localizing a pitch, an
English-speaking user + a Chinese codebase, or a Chinese paper presented to an English audience — is a
deck that drifts: English headings over Chinese bullets, one slide in the wrong language, a stray
translated-vs-untranslated mix. Pick the **target language** (step 0) and hold it across the whole deck.

- **Decide the target language explicitly.** Default to the language the *user* is
  writing in. **When the source material's language differs from the user's**, or it's
  otherwise ambiguous, **ask** which language the slides should be in — don't assume the
  source's language.
- **Translate the content into the target language** — don't paste source text verbatim
  in the other language just because that's how the source had it (faithfulness is to the
  *facts*, not the source's language).
- **Legitimate exceptions (not "mixing"):** established technical terms, proper nouns,
  brand/product names, acronyms, units, math symbols, and code/identifiers may stay in
  their original form — e.g. a Chinese deck can say "基于 Transformer 的重建" or "DeepSeek
  API"; that's normal, not a language violation.
- **Mixed / bilingual only on request.** Only produce a deck that mixes languages (e.g.
  EN + 中文 lines together, or a bilingual conference deck) if the user explicitly asks.
  Then do it *systematically* — the same pairing on every slide (e.g. English title with
  a 中文 subtitle throughout), not ad-hoc drift.

## The one required change: set a script-appropriate font

deckkit's default `FONT` (Calibri) has **no CJK glyphs**. It still *renders* here only
because LibreOffice silently substitutes a CJK font — but in the user's PowerPoint that
substitution is uncontrolled (wrong/inconsistent font, possibly tofu □□□ on a machine
without a good fallback). So for a CJK deck, set the East-Asian font explicitly:

```python
import deckkit
deckkit.FONT   = "Calibri"      # Latin letters + numbers
deckkit.EAFONT = "Hiragino Sans GB"  # CJK glyphs (macOS render-loop-safe; or "Microsoft YaHei" / "Noto Sans CJK SC")
```

`EAFONT` makes every run carry **both** `<a:latin>` (for Latin/numbers) **and** `<a:ea>`
(for CJK) — so PowerPoint/Keynote render Chinese with *your* chosen font while English
and numbers stay on `FONT`. Mixed "中文 + English 28%" text then looks intentional and
travels correctly. (Without `EAFONT`, CJK falls back to an uncontrolled default.)

🔴 **A run tuple's font slot is the LATIN face — the CJK face is the SEVENTH slot.** This is the
one place where following the documented call shape produces a silent no-op, so it is worth the
sentence: `text()` takes runs as `(text, size, colour, bold, italic, latin_face, ea_face)`, the
sixth element writes `<a:latin>`, and **CJK glyphs render from `<a:ea>`**. So

```python
dk.text(s, x, y, w, h, [[("认识 LUMC", 40, INK, True, False, "Songti SC")]])          # ✗
dk.text(s, x, y, w, h, [[("认识 LUMC", 40, INK, True, False, "Helvetica Neue", "Songti SC")]])  # ✓
```

the first line sets the Latin face of a run whose only Latin content is the acronym, and every
Chinese character in it renders in `EAFONT`. *(Measured: on a real build this made 6 of 14 slides
carry a title in a face nobody chose, for the whole build, while the deck looked plausible because
`EADISPLAY` happened to hold the intended face for the components that read it. Swapping `EAFONT`
moved 25,570 px of a rendered title; swapping the run tuple's font moved none of the CJK glyphs.)*
Omitting the seventh slot keeps the old behaviour exactly — `EAFONT` still applies — so this is an
addition, not a change. **`CJK_FACE_UNREACHED`** reports the mistake: a CJK-capable face named in
slot 6 on a run that contains CJK, where `<a:ea>` says something else.

🔴 **Setting `EAFONT` never fixes a deck already built** — `lint_layout` runs at the END of the
build script, so by the time `CJK_NO_EA` tells you about it the runs exist. The remedy for the deck
in hand is one line, just above the lint:

```python
deckkit.retrofit_ea(prs, "Hiragino Sans GB")   # or set EAFONT above and call retrofit_ea(prs)
deckkit.lint_layout(prs, strict=True)
prs.save(out)
```

**Pass the face unless `EAFONT` is already set** — with no face resolvable anywhere it raises
rather than returning 0, because a silent no-op would clear the lint line without fixing a glyph.
It returns the count of runs it stamped.

**Two different causes, two different follow-ups.** If the runs came from deckkit helpers and you
simply forgot `EAFONT`, setting it makes the next build clean. If they never went through
`set_font()` at all — a **redesign / surgical fix-pass** on a deck this skill did not author, or raw
`python-pptx` in the build script — `EAFONT` will not help next time either, because nothing on that
path reads it; keep calling `retrofit_ea`. (`open_template()` is *not* a source: it drops every
slide and python-pptx clones layout placeholders empty, so no template-owned run ever lands on a
slide. What a template really contributes is layout chrome — below.)

**What it reaches:** every CJK run under each slide, **including groups, table cells and
date/footer `<a:fld>` fields**, plus each **chart's** `c:txPr/a:defRPr` — a chart's category and
axis text lives in another part with no runs of its own. `CJK_NO_EA` can see none of those (it walks
`slide.shapes` and tests `has_text_frame`, false for a group, a table and a graphic frame), so the
fix is deliberately wider than the finding.

🔴 **It never overwrites a face the run already resolves**, its own or one INHERITED from the
paragraph's `defRPr` or the shape's `lstStyle` — which is where a supplied CJK template normally
keeps it. That is why the two agree by construction: the CRITICAL asks the same inheritance
question, so on a template deck neither the finding nor the fix touches 思源黑体 / 方正黑体 /
whatever the template chose. An `EADISPLAY` cover stays too. (`<a:ea typeface=""/>` is *not* such a
face — that is OOXML's way of writing "none", and it gets filled.)

🔴 **Layouts and masters are the one real gap, and it is loud.** Both the finding and the fix stop
at the slide, so a CJK shape sitting on a *layout* — which composites onto every slide that uses it
— is invisible to `CJK_NO_EA`, to `lint_deck.py`, and to `retrofit_ea`'s default pass. So the
default pass **counts them and says so**. When it does, re-run with `layouts=True` (it edits the
template's own parts, which is why it is opt-in), or set the face in the template.

**Translate the component CHROME too.** A few components ship English chrome words baked in;
on a non-English deck, pass the translated label so no stray English leaks onto an otherwise
Chinese slide: `eval_matrix(..., recommend_label="推荐方案", scale_label="评分")`,
`colophon(..., credits_label="团队", tooling_label="制作")`. Component data you pass — titles,
labels, values — is already in your language; only these built-in words need the override, so scan
the render for any stray English chrome.

### Font choices
| Role | Portable (recommended) | macOS | Windows |
|---|---|---|---|
| CJK sans (default) | Noto Sans CJK SC / Source Han Sans | **Hiragino Sans GB** (render-loop-safe), PingFang SC (final deck only — see warning) | Microsoft YaHei |
| CJK serif (formal) | Noto Serif CJK SC / Source Han Serif | Songti SC | SimSun |
| CJK brush/handwritten | — | Kaiti SC | KaiTi |
| Japanese / Korean | Noto Sans JP / KR | Hiragino Sans / Apple SD Gothic | Yu Gothic / Malgun Gothic |

Pick the CJK font to match the *purpose* the same way as Latin (`design-by-purpose.md`):
sans (Heiti/PingFang) for modern/corporate/talks, serif (Songti) for formal/defense.

**Render-loop trap (macOS):** in the LibreOffice render used for self-checks and the critic, **PingFang SC gets substituted with a handwriting-style face** — the QC loop then judges pixels that PowerPoint will never show. Default to **Hiragino Sans GB** on macOS (renders identically in LibreOffice and PowerPoint/Keynote); PingFang SC is fine for the final deck itself, but verify with a font that the render loop displays faithfully.

**Pair CJK fonts by role too — don't set the whole deck in one face** (see the "Type pairing"
section of `font-guidance.md`). Use a CJK **display** face for titles and a CJK **body** face for
text, plus a clean **Latin** face for the numbers/English inside CJK runs:
- `deckkit.EADISPLAY` = CJK title face (e.g. **Hiragino Sans GB**), `deckkit.EAFONT` = CJK body face
  (e.g. **Hiragino Sans GB** / **Noto Sans CJK SC**) — `title_bar`/`editorial_header` then set
  titles in EADISPLAY and body in EAFONT automatically. `wordmark()` is CJK-aware too — a CJK
  entity name resolves EADISPLAY→EAFONT→a CJK-capable system face, never a Latin-only font.
- `deckkit.DISPLAY`/`deckkit.FONT` = the Latin faces for those same roles, so digits/units/English
  (e.g. "≈40%", "1/5–1/7") render in a crisp Latin face, not the CJK fallback.

A tasteful, portable Chinese pairing: **Hiragino Sans GB** (titles and body — ONE family
differentiated by weight/size is the sanctioned pairing on a CJK deck, and the critic carves it;
don't read "display duplicates body" as a flaw here) or **Noto
Sans CJK SC** (body) + **Helvetica Neue/Arial** (Latin). Keep it to **≤2 text families (display +
body)** — the Latin and mono faces are functional roles, not extra style fonts — and apply it on
every slide. *(Avoid setting everything to "Arial" — it has no CJK glyphs, so the whole deck rides
an uncontrolled single fallback, the flat one-font look to fix.)*

### Bilingual (EN + 中文) typography system — one visual language, not two
When Latin and CJK share a deck (any 中文 deck with English terms/numbers, or a true bilingual deck),
design the **system** first and pick fonts second — the two scripts must read as one voice with
similar visual weight and spacing:
- **Pairing menu** (matched-proportion pairs — sans+sans by default; the warm and editorial rows
  are deliberate register moves; ONE Latin family + ONE CJK family, which
  together form the deck's text pairing; the CJK/EA and mono faces are *functional* roles under
  the ≤2-text-families rule, `font-guidance.md`; weights ≤3):
  *cross-platform / safest* → **Noto Sans + Noto Sans CJK SC** (or Source Han Sans); *macOS build
  loop* → **Helvetica Neue (or Inter, if installed) + Hiragino Sans GB** (PingFang SC only for the
  final deck, per the render-loop trap above); *Windows/Office* → **Aptos/Segoe UI + Microsoft
  YaHei or DengXian**; *technical* → **IBM Plex Sans + Source Han Sans**; *warm / friendly /
  teaching* → a rounded-humanist Latin (**Trebuchet MS / Verdana**, or Nunito if installed) +
  **LXGW WenKai / LXGW Bright** (free, OFL — warm Kai-flavoured without full brush formality; NOT
  preinstalled, so install it for the build loop, **flag install/embed at hand-off**, and check the
  render didn't silently substitute — the warm register dies in a substituted Heiti); *editorial /
  formal* → **Georgia (or another serif Latin) + Noto Serif CJK SC / Songti SC** — serif-Latin +
  serif-CJK is a deliberate *editorial* move, never an accident, and route big numerals through a
  **lining-figure face** (Georgia's old-style digits wobble next to CJK — `font-guidance.md`).
  And ANY cross-script serif/sans mix (either direction) must be deliberate, never an accident of
  per-script defaults.
- **Optical balance (the compensations no font pair does for you):** CJK glyphs fill the em-box, so
  at equal pt they read *larger and heavier* than Latin — in a mixed lockup, drop the CJK ~0.5–1pt
  or bump the Latin, and remember **CJK bold is visually heavier than Latin bold** (a CJK title at
  semibold often matches a Latin title at bold; reduce the CJK weight before reaching for a smaller
  size).
- **Width budget (CJK is full-width):** every CJK glyph takes a full em, so a Chinese label needs
  **~1.7–2× the width** of the same-length Latin label at equal pt. Size node/chip/pill/table-cell
  widths for the **CJK** text (widen the box or shorten the label); **never shrink the font to
  fit**, and confirm wrap in the render — the lint's wrap estimate is CJK-aware but approximate
  (real font metrics differ; a not-installed CJK face silently substitutes with different metrics).
- **Leading ladder (script-aware) — mind the UNITS:** targets are in **× font size** (the design
  convention): Latin ~1.15–1.3× · CJK multi-line body ~**1.3–1.45×** · mixed EN/中文 ~**1.35×**.
  PowerPoint's `line_spacing` *multiple* is a % of SINGLE spacing, which itself renders at ≈1.2×
  font size — so those targets correspond to `line_spacing` ≈ **1.08–1.21**, not 1.3–1.45.
  Single spacing that looks fine in Latin is cramped in CJK. `deckkit.text()` resolves this
  automatically when `line_spacing` is left unset (CJK-bearing paragraphs get `CJK_LS`=1.12
  ≈ 1.34× font size; Latin-only paragraphs stay at single — bump explicitly for an airy
  editorial look). Composite helpers (`bullet`/`callout`/`step_list`…) keep their tuned compact
  leading (≈1.22–1.30× font size) — for long CJK body text prefer a direct `text()` block. The
  render lint warns **`CJK TIGHT LEADING`** when a multi-line CJK paragraph ships at ≤ single
  spacing.
- **CJK↔Latin boundary spacing (盘古之白): pick ONE convention deck-wide.** Recommended: a normal
  space around inline Latin terms/digits — `全年 ARR 增长 51%` — applied everywhere; consistently
  none is acceptable, but *mixing* the two reads sloppy. The render lint warns **`CJK-LATIN
  SPACING`** when both conventions appear (≥3 boundaries of each, deck-wide). (Full-width punctuation still takes no flanking spaces.)
- **Hierarchy by weight before colour** for bilingual text (colour renders differently across the
  two scripts' stroke densities); highlight only keywords and numbers.

### Portability caveat (say this in step 6)
PowerPoint can embed fonts, but python-pptx can't, so the recipient's machine needs the
CJK font installed — or PowerPoint substitutes. Prefer a widely-installed font (PingFang
on macOS, Microsoft YaHei on Windows) or **Noto Sans/Serif CJK** for maximum portability,
and tell the user which font the deck expects.

## CJK typography habits (so it reads like a native deck, not translated)
- **No true italic.** CJK fonts fake italic by slanting — it looks wrong. Emphasize with
  **weight, colour, or size**, never italic, for CJK runs. (Latin runs can still italic.)
- **Full-width punctuation.** Use 。，、：；（）「」 — don't add Latin spaces around them,
  and don't end CJK sentences with a Latin period. **But for a lone, centred large mark** (a
  "?" in a box, a standalone "!"), use the **ASCII** form: a full-width `？！` sits
  left-of-centre within its advance and won't optically centre. Full-width is for *running*
  CJK text, not a centred single glyph.
- **Line-breaking (断句).** CJK wraps at any character (no spaces needed) — fine, but give text
  boxes a little more room and use the script-aware leading (CJK body ~1.3–1.45× font size =
  `line_spacing` ≈1.08–1.21; deckkit's `text()` default handles it when `line_spacing` is unset);
  dense CJK at tight leading is hard to read. Because it breaks anywhere, **check a wrapped title/term doesn't split
  at a meaningless point** (mid-term, or between a number and its unit) — widen the box or rebreak.
- **No 叠字 (overlapping glyphs).** If glyphs visibly collide/overlap, the box is too narrow or the
  tracking is off — widen the box or fix spacing; never squeeze CJK to fit.
- **Equal, consistent space width around an operator/symbol.** Around an inline `=` `≈` `→` `+` `：`,
  use the **same space character on both sides** — the classic CJK bug is a **full-width space (`　`,
  ~1 em) on one side and an ASCII space on the other**, so the symbol sits lopsided. Pick one (a
  full-width space reads well between CJK terms) and use it symmetrically; verify in the render.
- **No orphaned punctuation (避头尾 / kinsoku).** A line must not **start** with closing punctuation
  (`。， 、！？：；）》】" '`) and must not **end** with an opening one (`（《【" '`); and never leave a
  **lone punctuation mark on its own row** (a trailing `。`/`，` pushed to the next line is the ugly
  tell). PowerPoint/Keynote apply East-Asian line-break rules automatically *if the run carries an
  EA font* — so always set `EAFONT` (not Arial) — but a too-tight box can still strand a mark. Fix by
  **widening the box / lowering the size a touch / rebreaking the line** so punctuation stays attached
  to its character; for a hard case, hand-place the break. Same idea in Latin: don't let a lone ")" or
  "." wrap to its own line.
- **Density.** A CJK character carries more meaning per glyph, so for a **presented** deck terse
  points matter even more — resist filling the line just because it fits. *(A read-alone / reference
  CJK deck may run denser like any read-alone deck — then keep the script-aware leading (never below ~1.25× font size — `line_spacing` ≈1.04 — for CJK body) and the
  kinsoku guidance above; see `design-principles.md` "Delivery mode".)*
- **Numbers / Latin terms** inside CJK text render in `FONT` (the latin font) — choose a
  Latin font that pairs cleanly with the CJK one (Calibri/Arial with most sans CJK).

## Write like a human — kill the "AI taste" in the copy (voice; most acute in 中文)
Typography makes a CJK deck *render* native; **wording** makes it *sound* native. AI-written slide copy
has a recognizable, credibility-sapping smell — generic, over-formal, translation-shaped. Write the text
the way a sharp human professional in that field would, in the deck's language. This holds for every
language but is **most visible and most damaging in Chinese**, so check 中文 copy hardest.

**The "AI taste" tells to cut (中文):**
- **翻译腔 (translationese)** — English structures carried straight over: long `的…的…的` chains, "对于…来说",
  "作为…", overused `其 / 该 / 这一`, reflexive `被`-passives, "在…的背景下 / 随着…的发展" essay openers. →
  Reorder into natural Chinese, break the 的-chain, drop the scaffolding.
- **动词名词化 + 空动词 (nominalization)** — `进行优化 → 优化`; `实现了提升 → 提升了 / 更…`; `起到了…作用 → 能…`;
  `具有…的特点 →` (cut). Prefer the plain verb.
- **套话 / 空泛形容词 (hype filler)** — 强大、高效、全面、深入、极致、一站式、海量、无缝、赋能、助力、打造、
  全方位、显著提升（无数字）. These carry no information → replace with the **concrete fact** ("重建从 8 分钟降到
  12 秒") or delete.
- **机械排比 / 套路连接词** — every line "不仅…而且 / 首先…其次…最后", and filler like "值得一提的是、总而言之、
  众所周知、由此可见". → Vary the structure; trust the reader; cut connectors a person wouldn't say aloud.
- **节奏单一 + 破折号成瘾** — every sentence the same length, "X —— Y" on every line. → Vary length (let some
  lines be short fragments — slides aren't prose); use 破折号 sparingly.

**Do (any language):** concrete nouns + active verbs over abstract nouns; the specific number/name over a
vague claim; vary sentence length and structure; cut every adjective not doing work; match the **register
to the context** (sober for research, punchy for a pitch, plain-friendly for teaching — never
press-release-empty). **Read each line aloud / sub-vocalise: would a sharp person in this field actually
say it?** If it reads like a press release, a textbook abstract, or a translation when it shouldn't —
rewrite. *(English has its own tells — "leverage / robust / seamless / delve / unlock / in today's
fast-paced world / it's worth noting", reflexive triadic lists, em-dash overuse — same cure.)*

## Equations & figures
- `eq_par` / `equation_png` use ASCII + Greek (`EQFONT`) — unaffected by language. Don't
  put CJK *inside* `equation_png` (matplotlib's math font may lack the glyphs); label CJK
  around the equation with normal `text()` instead.
- Reuse the source's figures whole as always; if a figure has burned-in text in another
  language, that's the source's, not yours.

## Right-to-left scripts (Arabic / Hebrew) — limited
deckkit lays out left-to-right and doesn't handle RTL reordering or right alignment of
flow. You can set an Arabic/Hebrew font, but bidi layout, RTL bullet/indent direction,
and mirrored chrome are **not** supported well — treat RTL as a known limitation, flag it
to the user, and keep such decks very simple (or build RTL-critical slides by hand).

## Verify
The critic already flags tofu/missing glyphs — so render and **look**: every glyph is a
real character (no □), the CJK font is the one you chose, and emphasis isn't faux-italic.
